import os,time,json,urllib.request,signal
from pathlib import Path
r=Path('/content/p25_project');b=json.loads((r/'allocation_budget.json').read_text());end=b['deadline_unix']
while time.time()<end:time.sleep(min(20,max(.1,end-time.time())))
(r/'hard_deadline_reached.json').write_text(json.dumps(dict(unix=time.time(),deadline_unix=end)))
addr=os.environ.get('TBE_RUNTIME_ADDR')
assert addr,'Expected official Colab runtime management endpoint'
for _ in range(3):
 try:
  with urllib.request.urlopen(urllib.request.Request('http://'+addr+'/unassign',method='POST'),timeout=20) as response:assert response.status==200
  break
 except Exception:time.sleep(2)
